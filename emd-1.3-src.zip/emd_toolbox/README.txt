                 Empirical Mode Decomposition Toolbox(EMD)
                ==========================



EMD (version 1.0 For Scilab 5)
======================

Information about EMD can be found at 
http://atoms.scilab.org/toolboxes/emd_toolbox



AUTHORS
=======

G. Rilling
Naveed ur Rehman and Danilo P. Mandic
Holger Nahrstaedt
